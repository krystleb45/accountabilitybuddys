// Routing Configuration
const routingConfig = {
    // Core Routes
    routes: {
      home: '/',
      login: '/login',
      logout: '/logout',
      register: '/register',
      dashboard: '/dashboard',
      settings: '/settings',
      profile: '/profile',
      tasks: '/tasks',
      notFound: '*', // Fallback for 404
    },
  
    // Protected Routes (require authentication)
    protectedRoutes: ['/dashboard', '/settings', '/profile', '/tasks'],
  
    // Role-Based Routes (based on user roles)
    roleBasedRoutes: {
      admin: ['/dashboard', '/settings', '/profile', '/tasks'],
      user: ['/dashboard', '/profile', '/tasks'],
      guest: ['/login', '/register'],
    },
  
    // Default Route Redirects
    defaultRedirects: {
      authenticated: '/dashboard', // Redirect after successful login
      unauthenticated: '/login', // Redirect if user is not authenticated
    },
  
    // Function to check if a route is protected
    isProtectedRoute: function (route) {
      return this.protectedRoutes.includes(route);
    },
  
    // Function to get allowed routes for a specific role
    getRoleBasedRoutes: function (role) {
      return this.roleBasedRoutes[role] || [];
    },
  
    // Function to get the redirect route after login
    getRedirectRoute: function (isAuthenticated) {
      return isAuthenticated
        ? this.defaultRedirects.authenticated
        : this.defaultRedirects.unauthenticated;
    },
  };
  
  // Example Usage:
  // const userRoutes = routingConfig.getRoleBasedRoutes('user');
  // const isProtected = routingConfig.isProtectedRoute('/dashboard');
  
  export default routingConfig;
  